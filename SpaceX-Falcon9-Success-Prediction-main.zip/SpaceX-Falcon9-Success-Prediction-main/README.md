# SpaceX-Falcon9-Success-Prediction
 In this project we will predict if the Spacex Falcon 9 first stage will land successfully. Therefore if we can determine if the first stage will land, we can determine the cost of a launch.
 <img src=" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgJ4GsRcYLgIc7iEckg6UAecBgAM-78E-BhGhAVUtm&s">

- This is the final project of IBM Data Science Professional Certification Program 
- In this Project we need to complete following tasks
  - Data Collection with API
  - Data collection with Web Scraping
  - Data Wrangling
  - Exploratory Analysis using Pandas and Matplotlib
  - Exploratory Analysis using SQL
  - Build an Interactive Visual Analytics with Folium
  - Build an Interactive Dashboard with Plotly Dash
  - Complete the Machine Learning Prediction
  - Present Your Data-Driven Insights
